import {
  Controller,
  Post,
  Param,
  Body,
  HttpException,
  HttpStatus,
  Inject,
} from '@nestjs/common';
import type { IGameService } from '../../domain/service/game.service.interface';
import { GameMoveRequestDto } from '../model/request/game-move.request.dto';
import { GameResponseDto } from '../model/response/game.response.dto';
import { GameWebMapper } from '../mapper/game-web.mapper';
import { Game } from '../../domain/model/game.model';
import { GameBoard } from '../../domain/model/game-board.model';

/**
 * Game Controller
 * Handles HTTP requests for Tic-Tac-Toe game
 *
 * POST /game/:uuid - Foydalanuvchi yurishi va kompyuter javobi
 */
@Controller('game')
export class GameController {
  constructor(
    @Inject('IGameService')
    private readonly gameService: IGameService,
    private readonly gameWebMapper: GameWebMapper,
  ) {}

  /**
   * POST /game/:uuid
   *
   * Foydalanuvchidan yangilangan taxtani qabul qiladi,
   * validatsiya qiladi, kompyuter yuradi, javob qaytaradi
   *
   * @param uuid - O'yin UUID
   * @param gameMoveDto - Foydalanuvchi yuborgan taxta
   * @returns Kompyuter yurgandan keyingi holat
   */
  @Post(':uuid')
  async makeMove(
    @Param('uuid') uuid: string,
    @Body() gameMoveDto: GameMoveRequestDto,
  ): Promise<GameResponseDto> {
    try {
      // 1. Request DTO ni Domain modelga o'zgartirish
      const newGame = this.gameWebMapper.requestToDomain(uuid, gameMoveDto);

      // 2. Oldingi o'yin holatini olish
      const previousGame = await this.gameService.getGameById(uuid);

      // 3. Agar o'yin topilmasa, yangi o'yin yaratish
      if (!previousGame) {
        return await this.handleNewGame(newGame);
      }

      // 4. Oldingi o'yin tugagan bo'lsa, xato qaytarish
      if (this.gameService.isGameOver(previousGame)) {
        throw new HttpException(
          'Game is already over. Start a new game.',
          HttpStatus.BAD_REQUEST,
        );
      }

      // 5. Foydalanuvchi yurishini validatsiya qilish
      const isValid = this.gameService.validateGameBoard(newGame, previousGame);

      if (!isValid) {
        throw new HttpException(
          'Invalid move! You can only make one move at a time on an empty cell. Previous moves cannot be altered.',
          HttpStatus.BAD_REQUEST,
        );
      }

      // 6. Foydalanuvchi yurgandan keyin o'yin tugaganini tekshirish
      if (this.gameService.isGameOver(newGame)) {
        const winner = this.gameService.getWinner(newGame);
        await this.gameService.saveGame(newGame);

        return this.gameWebMapper.domainToResponse(newGame, true, winner);
      }

      // 7. Kompyuter yurishini hisoblash (Minimax)
      const gameAfterComputerMove =
        await this.gameService.calculateNextMove(newGame);

      // 8. Kompyuter yurgandan keyin o'yin tugaganini tekshirish
      const isGameOver = this.gameService.isGameOver(gameAfterComputerMove);
      const winner = isGameOver
        ? this.gameService.getWinner(gameAfterComputerMove)
        : null;

      // 9. Response DTO ga o'zgartirish va qaytarish
      return this.gameWebMapper.domainToResponse(
        gameAfterComputerMove,
        isGameOver,
        winner,
      );
    } catch (error) {
      // Agar HttpException bo'lsa, o'sha xatoni qaytarish
      if (error instanceof HttpException) {
        throw error;
      }

      // Boshqa xatolar uchun
      console.error('Error in makeMove:', error);
      throw new HttpException(
        'An error occurred while processing your move',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Yangi o'yinni boshqarish
   * Agar database da o'yin topilmasa
   *
   * @param game - Yangi o'yin
   * @returns Response
   */
  private async handleNewGame(game: Game): Promise<GameResponseDto> {
    // Bo'sh taxta yaratish (yangi o'yin)
    const emptyBoard = new GameBoard();
    const emptyGame = new Game(game.getId(), emptyBoard);

    // Validatsiya: foydalanuvchi faqat bitta X qo'ygan bo'lishi kerak
    const userMoveCount = this.countMoves(game.getBoard().getBoard());

    if (userMoveCount !== 1) {
      throw new HttpException(
        'New game must start with exactly one move from the player',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Foydalanuvchi yurishini validatsiya qilish
    const isValid = this.gameService.validateGameBoard(game, emptyGame);

    if (!isValid) {
      throw new HttpException(
        'Invalid first move! You must place exactly one X on an empty board.',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Kompyuter yurishi
    const gameAfterComputerMove =
      await this.gameService.calculateNextMove(game);

    // Javob qaytarish
    return this.gameWebMapper.domainToResponse(
      gameAfterComputerMove,
      false,
      null,
    );
  }

  /**
   * Taxta da qancha yurish qilinganini sanash
   *
   * @param board - O'yin taxtasi
   * @returns Yurishlar soni
   */
  private countMoves(board: number[][]): number {
    let count = 0;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (board[i][j] !== 0) {
          count++;
        }
      }
    }
    return count;
  }
}
