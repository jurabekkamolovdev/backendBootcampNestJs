/**
 * Game Response DTO
 * Serverdan qaytadigan o'yin holati
 *
 * Kompyuter yurgandan keyingi holat
 */
export class GameResponseDto {
  /**
   * O'yin UUID
   */
  uuid: string;

  /**
   * Yangilangan o'yin taxtasi (kompyuter yurishi bilan)
   *
   * Qiymatlar:
   *  0 = bo'sh
   *  1 = foydalanuvchi (X)
   * -1 = kompyuter (O)
   */
  board: number[][];

  /**
   * O'yin tugadimi?
   */
  isGameOver: boolean;

  /**
   * G'olib (agar o'yin tugagan bo'lsa)
   *
   * null = o'yin davom etmoqda
   * 'Player' = foydalanuvchi yutdi
   * 'Computer' = kompyuter yutdi
   * 'Draw' = durrang
   */
  winner: 'Player' | 'Computer' | 'Draw' | null;

  /**
   * Qo'shimcha xabar (optional)
   */
  message?: string;

  constructor(
    uuid: string,
    board: number[][],
    isGameOver: boolean,
    winner: 'Player' | 'Computer' | 'Draw' | null,
    message?: string,
  ) {
    this.uuid = uuid;
    this.board = board;
    this.isGameOver = isGameOver;
    this.winner = winner;
    this.message = message;
  }
}
