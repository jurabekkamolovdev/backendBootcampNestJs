import { Injectable } from '@nestjs/common';
import { Game } from '../../domain/model/game.model';
import { GameBoard } from '../../domain/model/game-board.model';
import { GameMoveRequestDto } from '../model/request/game-move.request.dto';
import { GameResponseDto } from '../model/response/game.response.dto';

/**
 * Game Web Mapper
 * Domain va Web modellarni o'zgartirish
 *
 * Web (DTO) ↔ Domain (Model)
 */
@Injectable()
export class GameWebMapper {
  /**
   * Request DTO ni Domain modelga o'zgartirish
   * GameMoveRequestDto → Game
   *
   * @param uuid - O'yin UUID
   * @param dto - Request DTO
   * @returns Domain Game modeli
   */
  requestToDomain(uuid: string, dto: GameMoveRequestDto): Game {
    // DTO dan board ni olish
    const boardData = dto.board;

    // GameBoard yaratish
    const gameBoard = new GameBoard(boardData);

    // Game yaratish
    const game = new Game(uuid, gameBoard);

    return game;
  }

  /**
   * Domain modelni Response DTO ga o'zgartirish
   * Game → GameResponseDto
   *
   * @param game - Domain Game modeli
   * @param isGameOver - O'yin tugadimi
   * @param winner - G'olib (1, -1, 0, yoki null)
   * @returns Response DTO
   */
  domainToResponse(
    game: Game,
    isGameOver: boolean,
    winner: number | null,
  ): GameResponseDto {
    // G'olibni matnli formatga o'zgartirish
    let winnerText: 'Player' | 'Computer' | 'Draw' | null = null;

    if (winner === 1) {
      winnerText = 'Player';
    } else if (winner === -1) {
      winnerText = 'Computer';
    } else if (winner === 0) {
      winnerText = 'Draw';
    }

    // Xabarni aniqlash
    let message: string | undefined;
    if (isGameOver) {
      if (winnerText === 'Player') {
        message = 'Congratulations! You won! 🎉';
      } else if (winnerText === 'Computer') {
        message = 'Computer won! Better luck next time! 🤖';
      } else if (winnerText === 'Draw') {
        message = "It's a draw! Well played! 🤝";
      }
    }

    // Response DTO yaratish
    const responseDto = new GameResponseDto(
      game.getId(),
      game.getBoard().getBoard(),
      isGameOver,
      winnerText,
      message,
    );

    return responseDto;
  }

  /**
   * Board massivni Domain GameBoard ga o'zgartirish
   * number[][] → GameBoard
   *
   * @param boardData - Taxta massivi
   * @returns GameBoard modeli
   */
  boardArrayToDomain(boardData: number[][]): GameBoard {
    return new GameBoard(boardData);
  }

  /**
   * Domain GameBoard ni massivga o'zgartirish
   * GameBoard → number[][]
   *
   * @param gameBoard - GameBoard modeli
   * @returns Taxta massivi
   */
  domainBoardToArray(gameBoard: GameBoard): number[][] {
    return gameBoard.getBoard();
  }
}
