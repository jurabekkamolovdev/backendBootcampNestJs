import { GameBoardEntity } from './game-board.entity';

/**
 * Game Entity
 * Database model for storing game data
 *
 * Bu - ma'lumotlar bazasida saqlanadigan o'yin modeli
 */
export class GameEntity {
  id: string; // UUID
  board: GameBoardEntity; // O'yin taxtasi
  createdAt: Date; // Yaratilgan vaqt
  updatedAt: Date; // Oxirgi o'zgarish vaqti

  constructor(
    id: string,
    board: GameBoardEntity,
    createdAt: Date,
    updatedAt: Date,
  ) {
    this.id = id;
    this.board = board;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
  }
}
